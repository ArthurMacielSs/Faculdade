void soma1(int*a);
void troca(float *end_valor1,float *end_valor2);
int ddd(long long x );
void soma1(int*a);
void troca(float *end_valor1,float *end_valor2);