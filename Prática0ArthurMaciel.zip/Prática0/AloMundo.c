#include <stdio.h> 
    int main(int argc, char *argv[]){
        printf("Alo Mundo! \n");
        return 0;
    }