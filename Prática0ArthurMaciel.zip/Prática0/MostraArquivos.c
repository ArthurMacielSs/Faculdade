#include <stdlib.h>

int main(int argc, char *argv[]){
    system("ls");
    return 0;
}